package Shape;

public class Circle extends Ellipse {
    /** TODO
     * Create a filled circle that is centered on (0, 0)
     * @param radius Radius of the Circle
     */
    public Circle(Double radius) {
        super(radius , radius );
    }
}
